# StaffInk (MVP)
Apri la cartella in Android Studio (Koala o successivo), sync Gradle, Run.

Uso: scrivi con lo stilo (o attiva "Dita: scrivi" nell'emulatore).
- Cerchio vuoto piccolo = semibreve; con gambo = minima; scarabocchio pieno = semiminima.
- Il simbolo scritto viene convertito in nota dopo 450 ms. Altezza dalla posizione sul rigo (chiave di violino).
- Modalita' "Seleziona": tocca una nota, poi Su/Giu'/Durata/Elimina. Annulla/Ripeti disponibili.
- "PDF" esporta e condivide lo spartito.

Chiave musicale: copia Bravura.otf (SMuFL, licenza OFL) in app/src/main/assets/. Senza, viene disegnata una "G".

Prossimi passi: sostituire Recognizer con un classificatore TFLite/ML Kit Digital Ink (dataset HOMUS),
aggiungere pause, alterazioni, crome, indicazione di tempo, salvataggio JSON/MusicXML.
