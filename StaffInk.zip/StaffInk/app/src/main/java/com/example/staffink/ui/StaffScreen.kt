package com.example.staffink.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.example.staffink.model.ScoreState
import com.example.staffink.recognition.Recognizer
import com.example.staffink.render.Layout
import com.example.staffink.render.PdfExporter
import com.example.staffink.render.ScoreRenderer
import kotlinx.coroutines.delay

private enum class Mode { WRITE, SELECT }

@Composable
fun StaffScreen(state: ScoreState) {
    val ctx = LocalContext.current
    val density = LocalDensity.current
    val space = with(density) { 10.dp.toPx() }
    var widthPx by remember { mutableFloatStateOf(0f) }
    val layout = remember(widthPx, space) { Layout(widthPx.coerceAtLeast(1f), space) }

    val strokes = remember { mutableStateListOf<List<Offset>>() }
    var current by remember { mutableStateOf(listOf<Offset>()) }
    var inkVersion by remember { mutableIntStateOf(0) }
    var mode by remember { mutableStateOf(Mode.WRITE) }
    var fingerDraw by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<Long?>(null) }
    val face = remember { ScoreRenderer.loadFace(ctx) }

    // Dopo ~450 ms senza nuovi tratti, il gruppo di tratti viene riconosciuto e sostituito.
    LaunchedEffect(inkVersion) {
        if (strokes.isEmpty()) return@LaunchedEffect
        delay(450)
        state.addRecognized(Recognizer.recognize(strokes.toList(), layout, state.score.systems), layout)
        strokes.clear()
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Button(onClick = { mode = if (mode == Mode.WRITE) Mode.SELECT else Mode.WRITE; selectedId = null }) {
                Text(if (mode == Mode.WRITE) "Scrivi" else "Seleziona")
            }
            OutlinedButton(onClick = { fingerDraw = !fingerDraw }) { Text(if (fingerDraw) "Dita: scrivi" else "Dita: scorri") }
            OutlinedButton(onClick = { state.undo() }) { Text("Annulla") }
            OutlinedButton(onClick = { state.redo() }) { Text("Ripeti") }
            selectedId?.let { id ->
                OutlinedButton(onClick = { state.moveStep(id, 1) }) { Text("Su") }
                OutlinedButton(onClick = { state.moveStep(id, -1) }) { Text("Giu'") }
                OutlinedButton(onClick = { state.cycleDuration(id) }) { Text("Durata") }
                OutlinedButton(onClick = { state.delete(id); selectedId = null }) { Text("Elimina") }
            }
            OutlinedButton(onClick = { state.addSystem() }) { Text("+ Rigo") }
            OutlinedButton(onClick = { state.clear(); selectedId = null }) { Text("Pulisci") }
            Button(onClick = { PdfExporter.share(ctx, state.score) }) { Text("PDF") }
        }

        Box(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Canvas(
                Modifier
                    .fillMaxWidth()
                    .height(with(density) { (layout.systemHeight * state.score.systems).toDp() })
                    .onSizeChanged { widthPx = it.width.toFloat() }
                    .pointerInput(mode, fingerDraw, layout) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            if (mode == Mode.SELECT) {
                                val up = waitForUpOrCancellation()
                                if (up != null) selectedId = state.hitTest(up.position, layout)
                                return@awaitEachGesture
                            }
                            val isPen = down.type == PointerType.Stylus || down.type == PointerType.Eraser
                            if (!isPen && !fingerDraw) return@awaitEachGesture // il dito scorre la pagina
                            down.consume()
                            val pts = mutableListOf(down.position)
                            inkVersion++
                            do {
                                val ev = awaitPointerEvent()
                                ev.changes.forEach { if (it.pressed) { pts.add(it.position); it.consume() } }
                                current = pts.toList()
                            } while (ev.changes.any { it.pressed })
                            strokes.add(pts.toList()); current = emptyList(); inkVersion++
                        }
                    }
            ) {
                drawIntoCanvas { c ->
                    ScoreRenderer.draw(c.nativeCanvas, layout, state.score, 0 until state.score.systems, selectedId, face)
                }
                (strokes.toList() + listOf(current)).forEach { pts ->
                    if (pts.size > 1) {
                        val p = Path().apply { moveTo(pts[0].x, pts[0].y); pts.drop(1).forEach { lineTo(it.x, it.y) } }
                        drawPath(p, Color(0xFF444444), style = Stroke(width = 3.dp.toPx()))
                    }
                }
            }
        }
    }
}
