package com.example.staffink.recognition

import androidx.compose.ui.geometry.Offset
import com.example.staffink.model.Duration
import com.example.staffink.render.Layout
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.roundToInt

data class Recognized(val system: Int, val x: Float, val step: Int, val duration: Duration)

/**
 * Riconoscitore a regole geometriche (MVP). Per ora capisce:
 *  - testa piena (scarabocchio piccolo)  -> semiminima
 *  - testa vuota (cerchio piccolo)       -> semibreve, o minima se c'e' un gambo
 *  - gambo (tratto verticale alto)       -> si associa alla testa vicina
 * Per aggiungere chiavi, pause, diesis ecc. sostituire/estendere con un classificatore ML
 * (vedi README) mantenendo lo stesso output: una lista di Recognized.
 */
object Recognizer {
    private class Info(val pts: List<Offset>) {
        val minX = pts.minOf { it.x }; val maxX = pts.maxOf { it.x }
        val minY = pts.minOf { it.y }; val maxY = pts.maxOf { it.y }
        val w get() = maxX - minX
        val h get() = maxY - minY
        val cx get() = (minX + maxX) / 2
        val cy get() = (minY + maxY) / 2
        val length: Float = pts.zipWithNext().sumOf { (a, b) -> (b - a).getDistance().toDouble() }.toFloat()
    }

    fun recognize(strokes: List<List<Offset>>, L: Layout, systems: Int): List<Recognized> {
        val sp = L.space
        val infos = strokes.filter { it.size >= 2 }.map(::Info)
        val stems = infos.filter { it.h > 2.2f * sp && it.w < 0.9f * sp }
        val heads = infos.filter { it.w in 0.4f * sp..2.4f * sp && it.h in 0.4f * sp..2.1f * sp }

        return heads.map { h ->
            val perimeter = Math.PI.toFloat() * (h.w + h.h) / 2f
            val filled = h.length / perimeter > 1.7f
            val hasStem = stems.any {
                abs(it.cx - h.cx) < 1.4f * sp && h.cy >= it.minY - 0.8f * sp && h.cy <= it.maxY + 0.8f * sp
            }
            val duration = when {
                filled -> Duration.QUARTER
                hasStem -> Duration.HALF
                else -> Duration.WHOLE
            }
            val system = floor(h.cy / L.systemHeight).toInt().coerceIn(0, systems - 1)
            val step = ((L.lineY(system, 0) - h.cy) / (sp / 2f)).roundToInt().coerceIn(-8, 16)
            Recognized(system, h.cx, step, duration)
        }
    }
}
