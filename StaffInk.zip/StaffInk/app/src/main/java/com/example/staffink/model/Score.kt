package com.example.staffink.model

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import com.example.staffink.recognition.Recognized
import com.example.staffink.render.Layout

enum class Duration(val beats: Float, val filled: Boolean, val stem: Boolean) {
    WHOLE(4f, false, false), HALF(2f, false, true), QUARTER(1f, true, true)
}

/** step: 0 = riga bassa del pentagramma (Mi4 in chiave di violino), +1 per ogni linea/spazio verso l'alto. */
data class Note(val id: Long, val system: Int, val step: Int, val duration: Duration) {
    val pitchName: String
        get() {
            val idx = 2 + step // Do4 = 0
            return "CDEFGAB"[Math.floorMod(idx, 7)].toString() + (4 + Math.floorDiv(idx, 7))
        }
}

data class Score(val systems: Int = 6, val notes: List<Note> = emptyList()) {
    fun notesIn(system: Int) = notes.filter { it.system == system }

    fun insert(n: Note, index: Int): Score {
        val cur = notesIn(n.system).toMutableList()
        cur.add(index.coerceIn(0, cur.size), n)
        return copy(notes = notes.filter { it.system < n.system } + cur + notes.filter { it.system > n.system })
    }

    fun update(id: Long, f: (Note) -> Note) = copy(notes = notes.map { if (it.id == id) f(it) else it })
    fun remove(id: Long) = copy(notes = notes.filter { it.id != id })

    fun positions(L: Layout): List<Pair<Note, Offset>> =
        (0 until systems).flatMap { s ->
            notesIn(s).mapIndexed { i, n -> n to Offset(L.noteX(i), L.noteY(s, n.step)) }
        }
}

class ScoreState {
    var score by mutableStateOf(Score())
        private set
    private val undoStack = ArrayDeque<Score>()
    private val redoStack = ArrayDeque<Score>()
    private var nextId = 1L

    private fun commit(s: Score) {
        undoStack.addLast(score); redoStack.clear(); score = s
    }

    fun undo() { undoStack.removeLastOrNull()?.let { redoStack.addLast(score); score = it } }
    fun redo() { redoStack.removeLastOrNull()?.let { undoStack.addLast(score); score = it } }

    fun addRecognized(list: List<Recognized>, L: Layout) {
        var s = score
        var changed = false
        for (r in list.sortedBy { it.x }) {
            val cur = s.notesIn(r.system)
            if (cur.size >= L.capacity) continue
            val idx = cur.indices.count { L.noteX(it) < r.x }
            s = s.insert(Note(nextId++, r.system, r.step, r.duration), idx)
            changed = true
        }
        if (changed) commit(s)
    }

    fun hitTest(p: Offset, L: Layout): Long? =
        score.positions(L).minByOrNull { (it.second - p).getDistance() }
            ?.takeIf { (it.second - p).getDistance() < 1.6f * L.space }?.first?.id

    fun moveStep(id: Long, d: Int) = commit(score.update(id) { it.copy(step = (it.step + d).coerceIn(-8, 16)) })
    fun cycleDuration(id: Long) = commit(score.update(id) {
        it.copy(duration = Duration.values()[(it.duration.ordinal + 1) % Duration.values().size])
    })
    fun delete(id: Long) = commit(score.remove(id))
    fun addSystem() = commit(score.copy(systems = score.systems + 1))
    fun clear() = commit(Score(score.systems))
}
