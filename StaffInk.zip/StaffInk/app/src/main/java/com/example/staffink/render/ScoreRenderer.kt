package com.example.staffink.render

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.example.staffink.model.Score

/** Geometria del pentagramma. Tutte le misure derivano da `space` (distanza tra due linee). */
class Layout(val width: Float, val space: Float, val noteSpacing: Float = space * 3.6f) {
    val systemHeight = space * 12
    val leftEdge = space * 1.5f
    val rightEdge = width - space * 1.5f
    val firstNoteX = leftEdge + space * 5
    val capacity get() = (((rightEdge - firstNoteX) / noteSpacing).toInt()).coerceAtLeast(1)

    fun topY(s: Int) = s * systemHeight + space * 5
    fun lineY(s: Int, i: Int) = topY(s) + (4 - i) * space
    fun noteX(i: Int) = firstNoteX + i * noteSpacing
    fun noteY(s: Int, step: Int) = lineY(s, 0) - step * space / 2f
}

object ScoreRenderer {
    /** Mettere Bravura.otf (SMuFL) in app/src/main/assets per la chiave musicale vera. */
    fun loadFace(ctx: Context): Typeface? =
        try { Typeface.createFromAsset(ctx.assets, "Bravura.otf") } catch (e: Exception) { null }

    fun draw(c: Canvas, L: Layout, score: Score, systems: IntRange, selectedId: Long?, face: Typeface?) {
        val sp = L.space
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.STROKE; strokeWidth = sp * 0.1f }
        val stemP = Paint(line).apply { strokeWidth = sp * 0.14f }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; style = Paint.Style.FILL }
        val outline = Paint(line).apply { strokeWidth = sp * 0.2f }
        val sel = Paint(line).apply { color = 0xFF1E88E5.toInt(); strokeWidth = sp * 0.15f }
        val clef = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; typeface = face ?: Typeface.SERIF }

        for (s in systems) {
            for (i in 0..4) c.drawLine(L.leftEdge, L.lineY(s, i), L.rightEdge, L.lineY(s, i), line)
            c.drawLine(L.leftEdge, L.lineY(s, 4), L.leftEdge, L.lineY(s, 0), line)
            if (face != null) { clef.textSize = sp * 4; c.drawText("\uE050", L.leftEdge + sp * 0.5f, L.lineY(s, 1), clef) }
            else { clef.textSize = sp * 5; c.drawText("G", L.leftEdge + sp * 0.8f, L.lineY(s, 1) + sp * 0.9f, clef) }

            var beats = 0f
            score.notesIn(s).forEachIndexed { i, n ->
                val x = L.noteX(i); val y = L.noteY(s, n.step)
                if (n.step <= -2) for (st in -2 downTo n.step step 2)
                    c.drawLine(x - sp * 0.9f, L.noteY(s, st), x + sp * 0.9f, L.noteY(s, st), line)
                if (n.step >= 10) for (st in 10..n.step step 2)
                    c.drawLine(x - sp * 0.9f, L.noteY(s, st), x + sp * 0.9f, L.noteY(s, st), line)
                c.save(); c.translate(x, y); c.rotate(-20f)
                val r = RectF(-sp * 0.62f, -sp * 0.45f, sp * 0.62f, sp * 0.45f)
                c.drawOval(r, if (n.duration.filled) fill else outline)
                c.restore()
                if (n.duration.stem) {
                    if (n.step < 6) c.drawLine(x + sp * 0.58f, y, x + sp * 0.58f, y - sp * 3.5f, stemP)
                    else c.drawLine(x - sp * 0.58f, y, x - sp * 0.58f, y + sp * 3.5f, stemP)
                }
                if (n.id == selectedId) c.drawCircle(x, y, sp * 1.1f, sel)
                beats += n.duration.beats
                if (beats % 4f == 0f) {
                    val bx = x + L.noteSpacing / 2
                    c.drawLine(bx, L.lineY(s, 4), bx, L.lineY(s, 0), line)
                }
            }
        }
    }
}
