package com.example.staffink

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.example.staffink.model.ScoreState
import com.example.staffink.ui.StaffScreen

class MainActivity : ComponentActivity() {
    private val state = ScoreState()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface { StaffScreen(state) }
            }
        }
    }
}
