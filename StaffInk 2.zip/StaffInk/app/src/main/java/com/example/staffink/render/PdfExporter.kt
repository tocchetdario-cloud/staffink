package com.example.staffink.render

import android.content.Context
import android.content.Intent
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.staffink.model.Score
import java.io.File
import java.io.FileOutputStream

object PdfExporter {
    fun export(ctx: Context, score: Score): File {
        val pageW = 595; val pageH = 842; val margin = 36f; val space = 8f
        val last = (score.notes.maxOfOrNull { it.system } ?: 0)
        val maxCount = (0..last).maxOf { score.notesIn(it).size }.coerceAtLeast(1)
        val base = Layout(pageW.toFloat(), space)
        val spacing = ((base.rightEdge - base.firstNoteX) / maxCount).coerceAtMost(space * 6)
        val L = Layout(pageW.toFloat(), space, spacing)
        val perPage = ((pageH - 2 * margin) / L.systemHeight).toInt()
        val face = ScoreRenderer.loadFace(ctx)

        val doc = PdfDocument()
        var pageNo = 1
        for (first in 0..last step perPage) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo++).create())
            page.canvas.translate(0f, margin - first * L.systemHeight)
            ScoreRenderer.draw(page.canvas, L, score, first..minOf(last, first + perPage - 1), null, face)
            doc.finishPage(page)
        }
        val dir = File(ctx.cacheDir, "pdf").apply { mkdirs() }
        val file = File(dir, "spartito.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    fun share(ctx: Context, score: Score) {
        val file = export(ctx, score)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Esporta spartito"))
    }
}
