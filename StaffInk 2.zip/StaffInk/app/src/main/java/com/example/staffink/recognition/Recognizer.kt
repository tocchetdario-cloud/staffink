package com.example.staffink.recognition

import androidx.compose.ui.geometry.Offset
import com.example.staffink.model.Duration
import com.example.staffink.render.Layout
import kotlin.math.floor
import kotlin.math.abs
import kotlin.math.roundToInt

data class Recognized(
    val system: Int, val x: Float, val step: Int, val duration: Duration, val rest: Boolean = false
)

/**
 * Riconoscitore a regole geometriche (MVP). Capisce:
 *  - testa piena (scarabocchio piccolo)  -> semiminima
 *  - testa vuota (cerchio piccolo)       -> semibreve, o minima se c'e' un gambo
 *  - trattino orizzontale corto          -> pausa: sotto una linea = semibreve, sopra una linea = minima
 *  - zig-zag verticale alto              -> pausa di semiminima
 */
object Recognizer {
    private class Info(val pts: List<Offset>) {
        val minX = pts.minOf { it.x }; val maxX = pts.maxOf { it.x }
        val minY = pts.minOf { it.y }; val maxY = pts.maxOf { it.y }
        val w get() = maxX - minX
        val h get() = maxY - minY
        val cx get() = (minX + maxX) / 2
        val cy get() = (minY + maxY) / 2
        val length: Float = pts.zipWithNext().sumOf { (a, b) -> (b - a).getDistance().toDouble() }.toFloat()
    }

    fun recognize(strokes: List<List<Offset>>, L: Layout, systems: Int): List<Recognized> {
        val sp = L.space
        val infos = strokes.filter { it.size >= 2 }.map(::Info)

        // gambo: tratto verticale alto e DRITTO
        val stems = infos.filter { it.h > 2.2f * sp && it.w < 0.9f * sp && it.length / it.h < 1.3f }
        // pausa di semiminima: tratto alto e a zig-zag
        val quarterRests = infos.filter {
            it.h in 2f * sp..4.5f * sp && it.w in 0.4f * sp..2f * sp && it.length / it.h >= 1.3f
        }
        // pause di semibreve/minima: trattino piatto
        val barRests = infos.filter {
            it.w in 0.8f * sp..2.5f * sp && it.h < 0.7f * sp && it.w / maxOf(it.h, 0.01f) >= 2.5f
        }
        val heads = infos.filter {
            it.w in 0.4f * sp..2.4f * sp && it.h in 0.4f * sp..2.1f * sp &&
                it.w / it.h < 2.5f && it !in quarterRests && it !in barRests
        }

        fun systemOf(cy: Float) = floor(cy / L.systemHeight).toInt().coerceIn(0, systems - 1)
        val out = mutableListOf<Recognized>()

        for (h in heads) {
            val perimeter = Math.PI.toFloat() * (h.w + h.h) / 2f
            val filled = h.length / perimeter > 1.7f
            val hasStem = stems.any {
                abs(it.cx - h.cx) < 1.4f * sp && h.cy >= it.minY - 0.8f * sp && h.cy <= it.maxY + 0.8f * sp
            }
            val duration = when {
                filled -> Duration.QUARTER
                hasStem -> Duration.HALF
                else -> Duration.WHOLE
            }
            val system = systemOf(h.cy)
            val step = ((L.lineY(system, 0) - h.cy) / (sp / 2f)).roundToInt().coerceIn(-8, 16)
            out += Recognized(system, h.cx, step, duration)
        }
        for (b in barRests) {
            val system = systemOf(b.cy)
            val nearest = ((L.lineY(system, 0) - b.cy) / sp).roundToInt().coerceIn(0, 4)
            val above = b.cy < L.lineY(system, nearest)   // sopra la linea -> appoggiata -> minima
            out += Recognized(system, b.cx, 0, if (above) Duration.HALF else Duration.WHOLE, rest = true)
        }
        for (q in quarterRests) {
            out += Recognized(systemOf(q.cy), q.cx, 0, Duration.QUARTER, rest = true)
        }
        return out
    }
}
